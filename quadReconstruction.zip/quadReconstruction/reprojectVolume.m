function reprojectVolume(im,clb,volumes)
figure,imshow(im),hold on
s=size(im);
proj=projection(clb,volumes.vol);
% proj(1,proj(1,:)<=0)=1;
% proj(1,proj(1,:)>s(2))=s(2);
% proj(2,proj(2,:)<=0)=1;
% proj(2,proj(2,:)>s(1))=s(1);

for cV=1:length(volumes.value)
    curRange=((cV-1)*8+1):(cV*8);
    if (polyarea(proj(1,curRange),proj(2,curRange))>1) %if the points are colinear, convhull crashes
        tP=proj(:,curRange);
%        k=convhull(tP(2,:),tP(1,:));
%        tP=round([tP(2,k); tP(1,k)]);
%         tP(tP<=0)=1;
%         tP(1,tP(1,:)>s(1))=s(1);
%         tP(2,tP(2,:)>s(2))=s(2);
        
        if (isnan(volumes.value(cV)))
            val=[1 0 0];
        else
            if (volumes.value(cV)<0)
                val=[0 0 -volumes.value(cV)];
            else
                val=[0 volumes.value(cV) 0];
            end
            plot(tP(1,:),tP(2,:),'color',val)
        end
        %if (max(val)>0.75)
            
        %end
        
        
    end
end
end