function newVol=sliceCube(vol,subcube)

if (subcube==1)
    newVol(1,:)=vol(1,:);
    newVol(2,:)=(vol(1,:)+vol(2,:))/2;
    newVol(3,:)=(vol(1,:)+vol(2,:)+vol(3,:)+vol(4,:))/4;
    newVol(4,:)=(vol(1,:)+vol(4,:))/2;
    newVol(5,:)=(vol(1,:)+vol(4,:)+vol(5,:)+vol(8,:))/4;
    newVol(6,:)=mean(vol);
    newVol(7,:)=(vol(1,:)+vol(2,:)+vol(7,:)+vol(8,:))/4;
    newVol(8,:)=(vol(1,:)+vol(8,:))/2;
end

if (subcube==2)
    newVol(1,:)=(vol(1,:)+vol(2,:))/2;
    newVol(2,:)=vol(2,:);
    newVol(3,:)=(vol(2,:)+vol(3,:))/2;
    newVol(4,:)=(vol(1,:)+vol(2,:)+vol(3,:)+vol(4,:))/4;
    newVol(5,:)=mean(vol);
    newVol(6,:)=(vol(2,:)+vol(3,:)+vol(6,:)+vol(7,:))/4;
    newVol(7,:)=(vol(2,:)+vol(7,:))/2;
    newVol(8,:)=(vol(1,:)+vol(2,:)+vol(7,:)+vol(8,:))/4;
end

if (subcube==3)
    newVol(1,:)=(vol(1,:)+vol(2,:)+vol(3,:)+vol(4,:))/4;
    newVol(2,:)=(vol(2,:)+vol(3,:))/2;
    newVol(3,:)=vol(3,:);
    newVol(4,:)=(vol(3,:)+vol(4,:))/2;
    newVol(5,:)=(vol(3,:)+vol(4,:)+vol(5,:)+vol(6,:))/4;
    newVol(6,:)=(vol(3,:)+vol(6,:))/2;
    newVol(7,:)=(vol(2,:)+vol(3,:)+vol(6,:)+vol(7,:))/4;
    newVol(8,:)=mean(vol);
end

if (subcube==4)
    newVol(1,:)=(vol(1,:)+vol(4,:))/2;
    newVol(2,:)=(vol(1,:)+vol(2,:)+vol(3,:)+vol(4,:))/4;
    newVol(3,:)=(vol(3,:)+vol(4,:))/2;
    newVol(4,:)=vol(4,:);
    newVol(5,:)=(vol(4,:)+vol(5,:))/2;
    newVol(6,:)=(vol(3,:)+vol(4,:)+vol(5,:)+vol(6,:))/4;
    newVol(7,:)=mean(vol);
    newVol(8,:)=(vol(1,:)+vol(4,:)+vol(5,:)+vol(8,:))/4;
end

if (subcube==5)
    newVol(1,:)=(vol(1,:)+vol(4,:)+vol(5,:)+vol(8,:))/4;
    newVol(2,:)=mean(vol);
    newVol(3,:)=(vol(3,:)+vol(4,:)+vol(5,:)+vol(6,:))/4;
    newVol(4,:)=(vol(4,:)+vol(5,:))/2;
    newVol(5,:)=vol(5,:);
    newVol(6,:)=(vol(5,:)+vol(6,:))/2;
    newVol(7,:)=(vol(5,:)+vol(6,:)+vol(7,:)+vol(8,:))/4;
    newVol(8,:)=(vol(5,:)+vol(8,:))/2;
end

if (subcube==6)
    newVol(1,:)=mean(vol);
    newVol(2,:)=(vol(2,:)+vol(3,:)+vol(6,:)+vol(7,:))/4;
    newVol(3,:)=(vol(3,:)+vol(6,:))/2;
    newVol(4,:)=(vol(3,:)+vol(4,:)+vol(5,:)+vol(6,:))/4;
    newVol(5,:)=(vol(5,:)+vol(6,:))/2;
    newVol(6,:)=vol(6,:);
    newVol(7,:)=(vol(6,:)+vol(7,:))/2;
    newVol(8,:)=(vol(5,:)+vol(6,:)+vol(7,:)+vol(8,:))/4;
end

if (subcube==7)
    newVol(1,:)=(vol(1,:)+vol(2,:)+vol(7,:)+vol(8,:))/4;
    newVol(2,:)=(vol(2,:)+vol(7,:))/2;
    newVol(3,:)=(vol(2,:)+vol(3,:)+vol(6,:)+vol(7,:))/4;
    newVol(4,:)=mean(vol);
    newVol(5,:)=(vol(5,:)+vol(6,:)+vol(7,:)+vol(8,:))/4;
    newVol(6,:)=(vol(6,:)+vol(7,:))/2;
    newVol(7,:)=vol(7,:);
    newVol(8,:)=(vol(7,:)+vol(8,:))/2;
end

if (subcube==8)
    newVol(1,:)=(vol(1,:)+vol(8,:))/2;
    newVol(2,:)=(vol(1,:)+vol(2,:)+vol(7,:)+vol(8,:))/4;
    newVol(3,:)=mean(vol);
    newVol(4,:)=(vol(1,:)+vol(4,:)+vol(5,:)+vol(8,:))/4;
    newVol(5,:)=(vol(5,:)+vol(8,:))/2;
    newVol(6,:)=(vol(5,:)+vol(6,:)+vol(7,:)+vol(8,:))/4;
    newVol(7,:)=(vol(7,:)+vol(8,:))/2;
    newVol(8,:)=vol(8,:);
end
end
