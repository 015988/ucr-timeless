clear
if (exist('conf.m','file'))
    conf;
else
    error('No configuration file found! (conf.m)');
end
nVideos=length(vids);

%% Video Opening
for c=1:nVideos
    videos(c)=VideoReader(vids{c});  %#ok<SAGROW,TNMLP>
end

%% Camera calibration
%for c=1:nVideos
%    clb(c)=loadCalibration(config.videos.clb{c});
%end
extr=load('extrinsic.mat');
for c=1:nVideos
     clb(c)=extr.clb(c).clb(1).clb; % only the first frame of the sequence
end

%% read one frame (testing only)
for c=1:nVideos
     curImage(c).im=read(videos(c),config.videos.first_frame(c));
     curImage(c).s=size(curImage(c).im);
     tmp=double(curImage(c).im)/255.0;
     %tTarget=double(squeeze(tmp(:,:,1,:)));
     % BLUE -> tTarget=double(squeeze(tmp(:,:,3,:))-squeeze(tmp(:,:,1,:)));
     % RED -> tTarget=double(squeeze(tmp(:,:,1,:))-squeeze(tmp(:,:,2,:)));
     tTarget=double(squeeze(tmp(:,:,3,:))-squeeze(tmp(:,:,1,:)));
     tTarget(tTarget<0)=0;
     %tTarget=tTarget/max(max(max(tTarget)));
     tRed=double(squeeze(min(tmp,[],3)));
     tRed=1-tRed;%/max(max(max(tRed)));
     tTarget=tTarget.*tRed;
     tmp=permute(tmp,[1 2 4 3]);
     tmpSize=size(tmp);
     tmp=reshape(tmp,[numel(tmp)/3 3]);
     tmp=reshape(rgb2hsv(tmp),[tmpSize(1) tmpSize(2) tmpSize(3) 3]);
     tmp=squeeze(tmp(:,:,:,2));
     curImage(c).obj=tmp.*tTarget;%/max(max(max(tmp))); %#ok<*SAGROW>
     curImage(c).obj=curImage(c).obj/max(max(max(curImage(c).obj)));
     curImage(c).obj=imdilate(curImage(c).obj,ones(12,12));
     curImage(c).obj=imclose(curImage(c).obj,ones(10,10));
end

%%
volumes.vol=zeros(config.mem.initial,3);
dim=config.volume.dim;
volumes.vol(1,:)=dim(:,1)';
volumes.vol(2,:)=[dim(1,2) dim(2,1) dim(3,1)];
volumes.vol(3,:)=[dim(1,2) dim(2,1) dim(3,2)];
volumes.vol(4,:)=[dim(1,1) dim(2,1) dim(3,2)];
volumes.vol(5,:)=[dim(1,1) dim(2,2) dim(3,2)];
volumes.vol(6,:)=[dim(1,2) dim(2,2) dim(3,2)];
volumes.vol(7,:)=[dim(1,2) dim(2,2) dim(3,1)];
volumes.vol(8,:)=[dim(1,1) dim(2,2) dim(3,1)];
volumes.done(1)=0;
volumes.numVideos(1)=nVideos;
volumes.value(1)=-1;

%% main loop
fprintf(1,'Starting reconstruction\n');
t=tic;
change=1;
curIt=1;
while (change==1)
    change=0;
    totalV=length(volumes.value); %saving the value so we can increase in the loop
    nV=totalV;
    config.mem.actual=length(volumes.vol);
    
    f=tic;
    
    for c=find(config.videos.active)
        % project all points into the images
        projPoints(c).p=round(projection(clb(c),volumes.vol(1:8*(nV),:)));
        projPoints(c).p(1,projPoints(c).p(1,:)<=0)=1;
        projPoints(c).p(1,projPoints(c).p(1,:)>curImage(c).s(2))=curImage(c).s(2);
        projPoints(c).p(2,projPoints(c).p(2,:)<=0)=1;
        projPoints(c).p(2,projPoints(c).p(2,:)>curImage(c).s(1))=curImage(c).s(1);
    end
    
    if ((8*nV)>(config.mem.actual*0.75))
        tic
        config.mem.step=config.mem.actual*0.25;
        fprintf(1,'Reallocating for nV: %g previous %g, next %g\n',nV*8,config.mem.actual,config.mem.actual+config.mem.step);        
        volumes.vol(config.mem.actual+config.mem.step,:)=zeros(1,3);
        config.mem.actual=config.mem.actual+config.mem.step;
        toc
    end
    
    for cV=find(volumes.done==0)
        %            ((cV-1)*8+1):(cV*8) -- reminder
        numV=0;                 % number of videos observing the region
        regDif=zeros(nVideos,1); %maximum difference in the projected region
        vals=zeros(nVideos,1);   %values
        cVmean=0;                                    % mean of the maximum values of each region -> value of volume
        curRange=((cV-1)*8+1):(cV*8);
        
        %calculates volume "discrepancy" and mean value of the
        %projected regions
        for c=find(config.videos.active)
            if (polyarea(projPoints(c).p(1,curRange),projPoints(c).p(2,curRange))>1) %if the points are colinear, convhull crashes
                tP=projPoints(c).p(:,curRange);
                k=convhull(tP(2,:),tP(1,:));
                tP=[tP(2,k); tP(1,k)];
                % that region is 'mask'
                bboxtP=round([min(tP,[],2); max(tP,[],2)]);
                tP(1,:)=(tP(1,:)-bboxtP(1))+1;
                tP(2,:)=(tP(2,:)-bboxtP(2))+1;
                mask=double(poly2mask(tP(2,:),tP(1,:),bboxtP(3)-bboxtP(1)+1,bboxtP(4)-bboxtP(2)+1));
                % any of it is on the image itself?
                if (any(any(mask)))
                    numV=numV+1;
                    
                    tIm=curImage(c).obj(bboxtP(1):bboxtP(3),bboxtP(2):bboxtP(4),:);
                    mask(mask==0)=NaN;
                    curProj=mask.*double(tIm);
                    if (any(any(curProj>0)))
                        cVmean=cVmean+nanmax(nanmax(curProj));
                        tMax=nanmax(nanmax(curProj));
                        regDif(c)=(tMax-(nanmin(nanmin(curProj))));
                        vals(c)=tMax;
                    end
                end
            end
        end
        volumes.numVideos(cV)=numV;
        
        % if the volume is observed by less than the minimum
        % cameras
        if (volumes.numVideos(cV)<config.volume.minVideos)
            volumes.done(cV)=1;
            volumes.value(cV)=NaN;
        else
            volumes.value(cV)=min(vals);
            if ((min(regDif)>0.1)&&(cubeVolume(volumes.vol(curRange,:))>config.volume.minVol))
                change=1;
                for subcube=2:8
                    nV=nV+1;
                    volumes.vol(((nV-1)*8+1):(nV*8),:)=sliceCube(volumes.vol(curRange,:),subcube);
                    volumes.done(nV)=0;
                    volumes.value(nV)=-abs(volumes.value(cV));
                    volumes.cVolume(nV)=cubeVolume(volumes.vol(((nV-1)*8+1):(nV*8),:));
                end
                volumes.vol(curRange,:)=sliceCube(volumes.vol(curRange,:),1);
                volumes.done(cV)=0;
                volumes.value(cV)=-abs(volumes.value(cV));
                %volumes.cVolume(cV)=cubeVolume(volumes.vol(curRange,:));
            else
                volumes.done(cV)=1;
                %volumes.value(cV)=abs(volumes.value(cV));
            end
        end
    end
    fprintf(1,'Current number of volumes: %d - %g s\n',nV,toc(f));
    %plotVolume(volumes)
    %for ii=1:length(clb)
    ii=1;
       reprojectVolume(curImage(ii).im,clb(ii),volumes)
       title(sprintf('Example of the voxel division - Iteration %d',curIt))
       print('-dpng','-r600',sprintf('Quad%d.png',curIt))
       curIt=curIt+1;
    %end
end
fprintf(1,'Finished - %g seconds.\n',toc(t));
save -v7.3 1cm
plotVolume(volumes);datestr(now)

print -dpng c.png
