function volume=cubeVolume(vPoints)
[~,volume]=convhulln(vPoints);

%when I created this function, I didn't know it was THAT easy...