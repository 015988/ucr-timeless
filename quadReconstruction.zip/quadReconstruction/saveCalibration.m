function saveCalibration(calib,name)
%function save_calibration(calib,name)
%calib -> calibration structure
%name  -> desired filename without extension

% K
% RT
% k p s

f=fopen([name '.clb'],'w');

%% KK
fprintf(f,'%e ',calib.KK');
fprintf(f,'\n');

%% RT
fprintf(f,'%e ',calib.RT');
fprintf(f,'\n');
%direct model
fprintf(f,'%e %e\n',calib.dir.k(1),calib.dir.k(2));
fprintf(f,'%e %e\n',calib.dir.p(1),calib.dir.p(2));
fprintf(f,'%e %e\n',calib.dir.s(1),calib.dir.s(2));

fprintf(f,'%e %e\n',calib.inv.k(1),calib.inv.k(2));
fprintf(f,'%e %e\n',calib.inv.p(1),calib.inv.p(2));
fprintf(f,'%e %e\n',calib.inv.s(1),calib.inv.s(2));

fclose(f);